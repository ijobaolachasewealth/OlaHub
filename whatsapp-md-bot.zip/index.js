const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const P = require('pino')
const path = require('path')

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('auth')
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true,
        logger: P({ level: 'silent' }),
    })

    sock.ev.on('creds.update', saveCreds)

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0]
        if (!msg.message) return
        const sender = msg.key.remoteJid
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text

        if (text?.startsWith('.menu')) {
            const buttons = [
                { buttonId: '.quote', buttonText: { displayText: '💬 Quote' }, type: 1 },
                { buttonId: '.help', buttonText: { displayText: '📖 Help' }, type: 1 }
            ]
            const buttonMessage = {
                text: 'Welcome to your custom MD Bot!

Choose one:',
                buttons: buttons,
                headerType: 1
            }
            await sock.sendMessage(sender, buttonMessage)
        }

        if (text?.startsWith('.help')) {
            await sock.sendMessage(sender, { text: 'Available Commands:
.menu
.quote
.help' })
        }

        if (text?.startsWith('.quote')) {
            await sock.sendMessage(sender, { text: '“Code is the closest thing we have to magic.” 💡' })
        }
    })

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update
        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect.error)?.output?.statusCode !== DisconnectReason.loggedOut
            if (shouldReconnect) startBot()
        } else if (connection === 'open') {
            console.log('✅ Bot is online!')
        }
    })
}

startBot()
